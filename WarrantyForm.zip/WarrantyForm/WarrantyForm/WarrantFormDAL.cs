﻿using System;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

namespace WarrantyForm
{
    public class WarrantFormDAL
    {
        public int add(WarrantFormModel warrantFormModel)
        {
            SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["dbconnection"].ConnectionString);
            conn.Open();
            SqlCommand cmd = new SqlCommand("sp_InsertWarrantFormDetails", conn);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@Date", warrantFormModel.date);
            cmd.Parameters.AddWithValue("@JobSite", warrantFormModel.JobSite);
            cmd.Parameters.AddWithValue("@Name", warrantFormModel.Name);
            cmd.Parameters.AddWithValue("@UnitSerial", warrantFormModel.UnitSerial);
            cmd.Parameters.AddWithValue("@Cyclecount", warrantFormModel.CycleCount);
            cmd.Parameters.AddWithValue("@Runhours", warrantFormModel.RunHours);
            cmd.Parameters.AddWithValue("@Setpoint", warrantFormModel.SetPoint);
            cmd.Parameters.AddWithValue("@blower", warrantFormModel.Blower);
            cmd.Parameters.AddWithValue("@serial#", warrantFormModel.Serial);
            cmd.Parameters.AddWithValue("@OriginSalesorder", warrantFormModel.SalesOrder);
            cmd.Parameters.AddWithValue("@RepOrganization", warrantFormModel.RepOrganisation);
            cmd.Parameters.AddWithValue("@Requestedby", warrantFormModel.RequestedBy);
            cmd.Parameters.AddWithValue("@PurchaseOrder", warrantFormModel.PurchaseOrder);
            cmd.Parameters.AddWithValue("@ContactCompany", warrantFormModel.ContactCompany);
            cmd.Parameters.AddWithValue("@AddressLine1", warrantFormModel.AddressLine1);
            cmd.Parameters.AddWithValue("@AddressLine2", warrantFormModel.AddressLine2);
            cmd.Parameters.AddWithValue("@City", warrantFormModel.City);
            cmd.Parameters.AddWithValue("@State", warrantFormModel.State);
            cmd.Parameters.AddWithValue("@zip", warrantFormModel.Zip);
            cmd.Parameters.AddWithValue("@Phone", warrantFormModel.Phone);
            cmd.Parameters.AddWithValue("@Email", warrantFormModel.EmailAddress);
            cmd.Parameters.AddWithValue("@ExplanationofProblem", warrantFormModel.ExplanationOfProblem);
            cmd.Parameters.AddWithValue("@Technicalservicesassistwithtroubleshooting", warrantFormModel.TechnicalServices);
            cmd.Parameters.AddWithValue("@Referenceticketnumber", warrantFormModel.TicketNumber);
            cmd.Parameters.AddWithValue("@shippingOptionsValue", warrantFormModel.ShippingOptionsValue);
            cmd.Parameters.AddWithValue("@ShippingOptionsText", warrantFormModel.ShippingOptionsText);
            cmd.Parameters.AddWithValue("@RequestedShipDate", warrantFormModel.RequestedShipDate);
            cmd.Parameters.AddWithValue("@Submittedby", warrantFormModel.SubmittedBy);
            cmd.Parameters.AddWithValue("@SubmittedDate", DateTime.Now);
             cmd.ExecuteNonQuery();
            cmd = new SqlCommand("select max(id) from tblWarrantySubmission", conn);
         
            int i = 0;
            i = Convert.ToInt32(cmd.ExecuteScalar());
            conn.Close();
            return i;
        }
        public void addQtyDetails(DataTable dt)
        {
            if (dt.Rows.Count > 0)
            {
                string consString = ConfigurationManager.ConnectionStrings["dbconnection"].ConnectionString;
                using (SqlConnection con = new SqlConnection(consString))
                {
                    using (SqlCommand cmd = new SqlCommand("sp_InsertQtyDetails"))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Connection = con;
                        cmd.Parameters.AddWithValue("@tblQtyPartDesCritionDetails", dt);
                        con.Open();
                        cmd.ExecuteNonQuery();
                        con.Close();
                    }
                }
            }

        }
    }
}