﻿using System;
using System.Collections.Generic;

namespace WarrantyForm
{
    public class WarrantFormModel
    {
        public DateTime date { get; set; }
        public string JobSite { get; set; }
        public string Name { get; set; }
        public string UnitSerial { get; set; }
        public string Blower { get; set; }
        public string Serial { get; set; }
        public string CycleCount { get; set; }
        public string SetPoint { get; set; }
        public string RunHours { get; set; }
        public long SalesOrder { get; set; }
        public string PurchaseOrder { get; set; }
        public string RequestedBy { get; set; }
        public string RepOrganisation { get; set; }
        public string ContactCompany { get; set; }
        public string AddressLine1 { get; set; }
        public string AddressLine2 { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public string Zip { get; set; }
        public string Phone { get; set; }
        public string ContactName { get; set; }
        public string EmailAddress { get; set; }
        public string ExplanationOfProblem { get; set; }
        public string TechnicalServices { get; set; }
        public string TicketNumber { get; set; }
        public string ShippingOptionsValue { get; set; }
        public string ShippingOptionsText { get; set; }
        public DateTime RequestedShipDate { get; set; }

       
        public string SubmittedBy { get; set; }
    }
   
}